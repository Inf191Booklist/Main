<?php
/*
Template Name: templatename
*/
?>