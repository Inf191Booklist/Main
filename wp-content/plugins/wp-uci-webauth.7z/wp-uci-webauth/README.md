wp-uci-webauth
==============

Replaces the default WordPress user authentication system with UCI's WebAuth services.
